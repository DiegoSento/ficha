// Datos de equipos con múltiples imágenes
const equipmentData = [
  {
    marca: "SENTO",
    modelo: "NODO FLUJO IFM V2 A - A0427",
    dimensiones: "270mm x 220mm x 53mm",
    operacion: "Rango de medición 0,1-25 l/min (20 a 60 °C)",
    Precisión: "±0.02 a ±0.05 pH ",
    alimentacion: "110v / 220v AC",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Medición precisa del caudal, del consumo y de la temperatura de los fluidos",
    caracteristicas:
      "Caudalímetro magneto-inductivo, sin batería, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 5 minutos",
    rangoOperacional: "Hasta 90 metros en línea de vista",
    imagenes: ["imag/ifm1.webp?height=250&width=400", "imag/ifm2.webp?height=250&width=400"],
  },
  {
    marca: "SENTO",
    modelo: "NODO RS232 V2 A - A0650",
    dimensiones: "136mm x 99mm x 85mm",
    operacion: "Comunicacion serial protocolo RS232",
    alimentacion: "110v / 220v AC",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Conexión con sensores RS232 (básculas)",
    caracteristicas: "Sin batería, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 5 minutos",
    rangoOperacional: "Hasta 80 metros en línea de vista",
    imagenes: ["imag/rs1.webp?height=250&width=400", "imag/rs2.webp?height=250&width=400"],
  },
  {
    marca: "SENTO",
    modelo: "NODO TEMPERATURA DE AGUA WT V2 B - A0310",
    dimensiones: "136mm x 99mm x 85mm",
    operacion: "-55°C hasta 125°C",
    Precisión: "±0,5 °C Precisión de -10 °C a +85 °C",
    alimentacion: "Batería Alcalina AA",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Sensor de temperatura a prueba de agua",
    caracteristicas: "Batería de 6 meses, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 10 minutos",
    rangoOperacional: "Hasta 80 metros en línea de vista",
    imagenes: [
      "imag/wt.webp?height=250&width=400",
      "imag/wt1.webp?height=250&width=400",
      "imag/wt2.webp?height=250&width=400",
    ],
  },
  {
    marca: "SENTO",
    modelo: "NODO TEMPERATURA Y HUMEDAD TH V2 B - A0269",
    dimensiones: "136mm x 99mm x 85mm",
    operacion: "0°C a 125°C",
    Precisión: "±3 % HR / ±0,3 ℃",
    alimentacion: "Batería Alcalina AA",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Medición de temperatura y humedad en exteriores",
    caracteristicas: "Batería de 6 meses, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 10 minutos",
    rangoOperacional: "Hasta 80 metros en línea de vista",
    imagenes: [
      "imag/th.webp?height=250&width=400",
      "imag/th1.webp?height=250&width=400",
      "imag/th2.webp?height=250&width=400",
    ],
  },
  {
    marca: "SENTO",
    modelo: "SENSOR FLUJO AGUA 1 PULGADAS V2 A - A0576",
    dimensiones: "136mm x 99mm x 85mm",
    operacion: "Contador de Pulsos",
    alimentacion: "110v / 220v AC",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Medición de flujo y consumo de agua",
    caracteristicas: "Sin batería, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 10 minutos",
    rangoOperacional: "Hasta 80 metros en línea de vista",
    imagenes: [
      "imag/wf1.webp?height=250&width=400",
      "imag/wf2.webp?height=250&width=400",
      "imag/wf3.webp?height=250&width=400",
    ],
  },
  {
    marca: "SENTO",
    modelo: "CONCENTRADOR WIFI GW V2 A - A0454",
    dimensiones: "270mm x 220mm x 53mm",
    operacion: "Recepcion de datos Lora",
    alimentacion: "110v / 220v AC",
    comunicacion: "WIFI 2400 MHz, Bluetooth",
    aplicacion: "Concentrador principal para recepción de datos",
    caracteristicas: "Batería de litio ion (6 horas), diseñado para ambientes contaminados (Clase A).",
    tiempoTransmision: "Continuo",
    rangoOperacional: "Hasta 90 metros en línea de vista",
    imagenes: ["imag/gw1.webp?height=250&width=400", "imag/gw2.webp?height=250&width=400"],
  },

  {
    marca: "SENTO",
    modelo: "NODO FORMALDEHIDO V1 A",
    dimensiones: "136mm x 99mm x 85mm",
    operacion: "Rango de detección: 0~5 ppm",
    Precisión: "±0,01 ppm",
    alimentacion: "110v / 220v AC",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Utiliza un módulo sensor de HCHO en el aire",
    caracteristicas: "Sin batería, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 5 minutos",
    rangoOperacional: "Hasta 80 metros en línea de vista",
    imagenes: ["imag/for1.webp?height=250&width=400", "imag/for2.webp?height=250&width=400"],
  },
  {
    marca: "SENTO",
    modelo: "NODO DE PULSOS V1 A - A0787",
    dimensiones: "136mm x 99mm x 85mm",
    operacion: "Contador de pulsos ",
    alimentacion: "110v / 220v AC",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Conexión 3 pines",
    caracteristicas: "Sin batería, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 5 minutos",
    rangoOperacional: "Hasta 80 metros en línea de vista",
    imagenes: ["imag/pul1.webp?height=250&width=400", "imag/pul2.webp?height=250&width=400"],
  },
  {
    marca: "SENTO",
    modelo: "NODO MODBUS RS485 V1 A - A0664",
    dimensiones: "136mm x 99mm x 85mm",
    operacion: "Protocolo de comunicación MODBUS",
    alimentacion: "110v / 220v AC",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Comunicación RS485 bidireccional Half duplex",
    caracteristicas: "Sin batería, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 5 minutos",
    rangoOperacional: "Hasta 80 metros en línea de vista",
    imagenes: ["imag/rs485.webp?height=250&width=400", "imag/rs4852.webp?height=250&width=400"],
  },
  {
    marca: "SENTO",
    modelo: " Nodo Modbus TCP A - A0651",
    dimensiones: "136mm x 99mm x 85mm",
    operacion: "Protocolo de comunicación Modbus/TCP",
    alimentacion: "110v / 220v AC",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Protocolo Modbus utilizado para comunicaciones a través de redes TCP/IP",
    caracteristicas: "Sin batería, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 5 minutos",
    rangoOperacional: "Hasta 80 metros en línea de vista",
    imagenes: ["imag/tcp1.webp?height=250&width=400", "imag/tcp2.webp?height=250&width=400"],
  },
  {
    marca: "SENTO",
    modelo: "CO2 TEMPERATURE HUMIDITY NODE CO&TH V2 A - 0451  ",
    dimensiones: "136mm x 99mm x 85mm",
    operacion: "Rango de medición de 0-2000 ppm",
    Precisión: "±50 ppm ±3% de la lectura ",
    alimentacion: "110v / 220v AC",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Medición de dióxido de carbono en el ambiente",
    caracteristicas: "Sin batería, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 5 minutos",
    rangoOperacional: "Hasta 80 metros en línea de vista",
    imagenes: ["imag/co2.webp?height=250&width=400", "imag/co21.webp?height=250&width=400"],
  },
  {
    marca: "SENTO",
    modelo: "Nodo Temperatura Industrial B-A0652",
    dimensiones: "136mm x 99mm x 85mm",
    operacion: "Medición de temperatura de -100 a 200 °C",
    Precisión: "±0.15°C ",
    alimentacion: "Batería Alcalina AA",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Medicion de temperatura en entornos industriales",
    caracteristicas: "Batería de 6 meses, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 10 minutos",
    rangoOperacional: "Hasta 80 metros en línea de vista",
    imagenes: [
      "imag/ind1.webp?height=250&width=400",
      "imag/ind2.webp?height=250&width=400",
      "imag/ind3.webp?height=250&width=400",
    ],
  },
  {
    marca: "SENTO",
    modelo: "KIT MODEM 4G V2.0 - A0560",
    dimensiones: "270mm x 220mm x 53mm",
    operacion: "Redes 4G/LTE (Cat 4), 3G, 2G",
    alimentacion: "110v / 220v AC",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Router industrial para conectividad 4G",
    caracteristicas: "Sin batería, diseñado para ambientes hostiles y contaminados (Clase A).",
    tiempoTransmision: "Continuo",
    rangoOperacional: "Cobertura de red celular",
    imagenes: ["imag/rou1.webp?height=250&width=400", "imag/rou2.webp?height=250&width=400"],
  },
  {
    marca: "SENTO",
    modelo: "NODO AGUA PH WN V2 A - A0561",
    dimensiones: "270mm x 220mm x 53mm",
    operacion: "0-14PH",
    Precisión: "±0.02 a ±0.05 pH",
    alimentacion: "110v / 220v AC",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Medición de PH en agua 0 ℃ – + 80 ℃, en línea y en tiempo real",
    caracteristicas: "Sin batería, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 15 minutos",
    rangoOperacional: "Hasta 90 metros en línea de vista",
    imagenes: [
      "imag/ph1.webp?height=250&width=400",
      "imag/ph2.webp?height=250&width=400",
      "imag/ph3.webp?height=250&width=400",
    ],
  },
]

// Variables globales para el estado del carrusel y modal
let currentModalEquipment = null
let currentModalImageIndex = 0
let autoplayIntervals = []
let selectedCardIndex = null

/**
 * Crea una tarjeta de equipo con carrusel de imágenes
 */
function createEquipmentCard(equipment, index) {
  // Crear slides para el carrusel
  const carouselSlides = equipment.imagenes
    .map(
      (imagen, imgIdx) => `
    <div class="carousel-slide ${imgIdx === 0 ? "active" : ""}">
      <img src="${imagen}" 
           alt="${equipment.modelo} - Imagen ${imgIdx + 1}" 
           loading="lazy"
           onerror="this.onerror=null; this.src='placeholder.svg?height=250&width=400'; this.classList.add('fallback-image')" />
    </div>
  `,
    )
    .join("")

  // Crear indicadores (dots) para el carrusel
  const carouselDots = equipment.imagenes
    .map(
      (_, imgIdx) => `
    <div class="dot ${imgIdx === 0 ? "active" : ""}" data-index="${imgIdx}" role="button" aria-label="Ver imagen ${
      imgIdx + 1
    }"></div>
  `,
    )
    .join("")

  // Retornar el HTML de la tarjeta completa
  return `
    <div class="equipment-card" style="animation-delay: ${index * 0.1}s" data-equipment-index="${index}">
      <h2>
        ${equipment.modelo}
        <span class="badge">${equipment.marca}</span>
      </h2>
      <div class="content">
        <div class="carousel-container" data-equipment-index="${index}">
          ${carouselSlides}
          <button class="carousel-btn prev-btn" data-action="prev" aria-label="Imagen anterior">
            <i class="fas fa-chevron-left" aria-hidden="true"></i>
          </button>
          <button class="carousel-btn next-btn" data-action="next" aria-label="Imagen siguiente">
            <i class="fas fa-chevron-right" aria-hidden="true"></i>
          </button>
          <div class="carousel-dots" role="tablist">
            ${carouselDots}
          </div>
        </div>
        <dl class="specs">
          <dt><i class="fas fa-ruler-combined" aria-hidden="true"></i> Dimensiones:</dt>
          <dd>${equipment.dimensiones}</dd>
          <dt><i class="fas fa-temperature-high" aria-hidden="true"></i> Operación:</dt>
          <dd>${equipment.operacion}</dd>
          <dt><i class="fas fa-crosshairs" aria-hidden="true"></i> Precisión:</dt>
          <dd>${equipment.Precisión || "No especificada"}</dd>
          <dt><i class="fas fa-plug" aria-hidden="true"></i> Alimentación:</dt>
          <dd>${equipment.alimentacion}</dd>
          <dt><i class="fas fa-wifi" aria-hidden="true"></i> Comunicación:</dt>
          <dd>${equipment.comunicacion}</dd>
          <dt><i class="fas fa-clock" aria-hidden="true"></i> Tiempo de Transmisión:</dt>
          <dd>${equipment.tiempoTransmision}</dd>
          <dt><i class="fas fa-broadcast-tower" aria-hidden="true"></i> Rango Operacional:</dt>
          <dd>${equipment.rangoOperacional}</dd>
        </dl>
        <h3>Aplicación:</h3>
        <p>${equipment.aplicacion}</p>
        <h3>Características:</h3>
        <p>${equipment.caracteristicas}</p>
      </div>
    </div>
  `
}

/**
 * Renderiza la lista de equipos en el DOM
 */
function renderEquipmentList(equipmentList = equipmentData) {
  // Limpiar cualquier intervalo de autoplay existente
  clearAllAutoplayIntervals()

  const equipmentListElement = document.getElementById("equipmentList")
  equipmentListElement.innerHTML = equipmentList
    .map((equipment, index) => createEquipmentCard(equipment, index))
    .join("")

  // Configurar carruseles y autoplay
  setupCarousels()
  setupAutoplay()
  setupCardSelection()

  // Usar la nueva función de animación
  animateCards()
}

/**
 * Configura la selección de tarjetas
 */
function setupCardSelection() {
  const cards = document.querySelectorAll(".equipment-card")

  // Crear overlay para el fondo oscuro
  const overlay = document.createElement("div")
  overlay.className = "overlay"
  document.body.appendChild(overlay)

  // Crear botón de cierre para cada tarjeta
  cards.forEach((card) => {
    const closeBtn = document.createElement("button")
    closeBtn.className = "close-card-btn"
    closeBtn.innerHTML = '<i class="fas fa-times"></i>'
    closeBtn.setAttribute("aria-label", "Cerrar")
    card.appendChild(closeBtn)

    closeBtn.addEventListener("click", (e) => {
      e.stopPropagation()
      deselectCard()
    })
  })

  cards.forEach((card) => {
    card.addEventListener("click", (e) => {
      // Si el clic fue en un botón o dot del carrusel, no seleccionar la tarjeta
      if (e.target.closest(".carousel-btn") || e.target.closest(".dot") || e.target.closest(".close-card-btn")) {
        return
      }

      // Verificar si la tarjeta ya está seleccionada
      const isAlreadySelected = card.classList.contains("selected")

      // Si ya hay una tarjeta seleccionada, deseleccionarla primero
      deselectCard()

      // Si no estaba seleccionada, marcarla
      if (!isAlreadySelected) {
        // Guardar la posición original de la tarjeta para restaurarla después
        const rect = card.getBoundingClientRect()
        card.dataset.originalTop = rect.top + window.scrollY
        card.dataset.originalLeft = rect.left + window.scrollX
        card.dataset.originalWidth = rect.width
        card.dataset.originalHeight = rect.height

        // Marcar la tarjeta como seleccionada
        card.classList.add("selected")

        // Mostrar el overlay
        overlay.classList.add("active")

        // Bloquear el scroll del body
        document.body.style.overflow = "hidden"

        // Guardar el índice de la tarjeta seleccionada
        selectedCardIndex = Number.parseInt(card.dataset.equipmentIndex)
      }
    })
  })

  // Función para deseleccionar la tarjeta actual
  function deselectCard() {
    const selectedCard = document.querySelector(".equipment-card.selected")
    if (selectedCard) {
      selectedCard.classList.remove("selected")
      overlay.classList.remove("active")
      document.body.style.overflow = ""
      selectedCardIndex = null
    }
  }

  // Cerrar al hacer clic en el overlay
  overlay.addEventListener("click", deselectCard)

  // Cerrar con la tecla Escape
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      deselectCard()
    }
  })
}

/**
 * Configura los event listeners para los carruseles
 */
function setupCarousels() {
  // Listener para clicks en los contenedores de carrusel
  const carouselContainers = document.querySelectorAll(".carousel-container")

  carouselContainers.forEach((container) => {
    const equipmentIndex = Number.parseInt(container.dataset.equipmentIndex)
    const equipment = equipmentData[equipmentIndex]

    // Listener para el contenedor (abre el modal)
    container.addEventListener("click", (e) => {
      // Si el clic fue en un botón, no abrir el modal
      if (e.target.closest(".carousel-btn") || e.target.closest(".dot")) {
        return
      }

      // Encuentra el índice de la imagen activa
      const activeSlideIndex = Array.from(container.querySelectorAll(".carousel-slide")).findIndex((slide) =>
        slide.classList.contains("active"),
      )

      openModal(equipment, activeSlideIndex)

      // Marcar la tarjeta como seleccionada
      const cards = document.querySelectorAll(".equipment-card")
      cards.forEach((card) => card.classList.remove("selected"))
      container.closest(".equipment-card").classList.add("selected")

      // Guardar el índice de la tarjeta seleccionada
      selectedCardIndex = equipmentIndex
    })

    // Listeners para los botones de navegación
    const prevButton = container.querySelector(".prev-btn")
    const nextButton = container.querySelector(".next-btn")

    prevButton.addEventListener("click", (e) => {
      e.stopPropagation()
      navigateCarousel(container, "prev")
    })

    nextButton.addEventListener("click", (e) => {
      e.stopPropagation()
      navigateCarousel(container, "next")
    })

    // Listeners para los dots
    const dots = container.querySelectorAll(".dot")
    dots.forEach((dot) => {
      dot.addEventListener("click", (e) => {
        e.stopPropagation()
        const dotIndex = Number.parseInt(dot.dataset.index)
        setActiveSlide(container, dotIndex)
      })
    })
  })
}

/**
 * Configura el autoplay para los carruseles
 */
function setupAutoplay() {
  const carouselContainers = document.querySelectorAll(".carousel-container")

  // Detectar si es un dispositivo móvil
  const isMobile = window.innerWidth <= 768 || "ontouchstart" in document.documentElement

  carouselContainers.forEach((container, index) => {
    // Intervalo más largo para móviles para ahorrar batería y transiciones más lentas
    const intervalTime = isMobile ? 10000 + index * 500 : 8000 + index * 500

    // Crear un intervalo para cada carrusel
    const interval = setInterval(() => {
      navigateCarousel(container, "next")
    }, intervalTime)

    // Guardar referencia al intervalo
    autoplayIntervals.push(interval)

    // Pausar autoplay al interactuar
    const pauseAutoplay = () => {
      clearInterval(interval)
    }

    // Reanudar autoplay al dejar de interactuar
    const resumeAutoplay = () => {
      const newInterval = setInterval(() => {
        navigateCarousel(container, "next")
      }, intervalTime)

      // Reemplazar el intervalo en el array
      const intervalIndex = autoplayIntervals.indexOf(interval)
      if (intervalIndex !== -1) {
        autoplayIntervals[intervalIndex] = newInterval
      } else {
        autoplayIntervals.push(newInterval)
      }
    }

    // Eventos para escritorio
    container.addEventListener("mouseenter", pauseAutoplay)
    container.addEventListener("mouseleave", resumeAutoplay)

    // Eventos para móviles
    container.addEventListener("touchstart", pauseAutoplay)
    container.addEventListener("touchend", resumeAutoplay)
  })
}

/**
 * Limpia todos los intervalos de autoplay
 */
function clearAllAutoplayIntervals() {
  autoplayIntervals.forEach((interval) => clearInterval(interval))
  autoplayIntervals = []
}

/**
 * Navega entre las imágenes del carrusel
 */
function navigateCarousel(container, direction) {
  const slides = container.querySelectorAll(".carousel-slide")
  const activeSlideIndex = Array.from(slides).findIndex((slide) => slide.classList.contains("active"))

  let newIndex
  if (direction === "prev") {
    newIndex = activeSlideIndex === 0 ? slides.length - 1 : activeSlideIndex - 1
  } else {
    newIndex = activeSlideIndex === slides.length - 1 ? 0 : activeSlideIndex + 1
  }

  setActiveSlide(container, newIndex)
}

/**
 * Establece la imagen activa en el carrusel
 */
function setActiveSlide(container, index) {
  const slides = container.querySelectorAll(".carousel-slide")
  const dots = container.querySelectorAll(".dot")

  // Desactivar todos
  slides.forEach((slide) => {
    slide.classList.remove("active")
    slide.style.zIndex = 0
  })

  dots.forEach((dot) => dot.classList.remove("active"))

  // Activar el nuevo
  slides[index].classList.add("active")
  slides[index].style.zIndex = 1
  dots[index].classList.add("active")

  // Efecto de transición suave (más lenta)
  slides.forEach((slide) => {
    if (!slide.classList.contains("active")) {
      slide.style.opacity = 0
      slide.style.transition = "opacity 1.2s ease-in-out"
    } else {
      slide.style.opacity = 1
      slide.style.transition = "opacity 1.2s ease-in-out"
    }
  })
}

/**
 * Abre el modal con la imagen seleccionada
 */
function openModal(equipment, imageIndex = 0) {
  currentModalEquipment = equipment
  currentModalImageIndex = imageIndex

  const modal = document.getElementById("fullscreenModal")
  const modalImage = document.getElementById("modalImage")
  const modalTitle = document.getElementById("modalTitle")
  const modalDescription = document.getElementById("modalDescription")
  const modalDots = document.getElementById("modalDots")

  // Configurar imagen y texto
  modalImage.src = equipment.imagenes[imageIndex]
  modalImage.alt = `${equipment.modelo} - Imagen ${imageIndex + 1}`
  modalTitle.textContent = equipment.modelo
  modalDescription.textContent = equipment.aplicacion

  // Crear los dots para el modal
  modalDots.innerHTML = ""
  equipment.imagenes.forEach((_, idx) => {
    const dot = document.createElement("div")
    dot.className = `dot ${idx === imageIndex ? "active" : ""}`
    dot.dataset.index = idx
    dot.setAttribute("role", "button")
    dot.setAttribute("aria-label", `Ver imagen ${idx + 1}`)
    dot.addEventListener("click", (e) => {
      e.stopPropagation()
      setModalImage(idx)
    })
    modalDots.appendChild(dot)
  })

  // Mostrar el modal con animación
  modal.style.display = "flex"

  // Detectar si el usuario prefiere reducir el movimiento
  const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches

  if (!prefersReducedMotion) {
    setTimeout(() => {
      modal.classList.add("active")
    }, 30)
  } else {
    modal.classList.add("active")
  }

  document.body.style.overflow = "hidden" // Evitar scroll

  // Enfoque en el botón de cerrar para accesibilidad
  setTimeout(() => {
    document.getElementById("closeModalBtn").focus()
  }, 100)

  // Detectar si es un dispositivo móvil para ajustar la interfaz
  const isMobile = window.innerWidth <= 768 || "ontouchstart" in document.documentElement
  if (isMobile) {
    // Ajustar botones para mejor accesibilidad en móviles
    document.getElementById("prevImageBtn").style.opacity = "1"
    document.getElementById("nextImageBtn").style.opacity = "1"
  }
}

/**
 * Cierra el modal
 */
function closeModal() {
  const modal = document.getElementById("fullscreenModal")

  // Animación de cierre
  modal.classList.remove("active")
  setTimeout(() => {
    modal.style.display = "none"
  }, 500) // Transición más rápida

  document.body.style.overflow = "" // Restaurar scroll

  currentModalEquipment = null
  currentModalImageIndex = 0
}

/**
 * Navega entre imágenes en el modal
 */
function navigateModal(direction) {
  if (!currentModalEquipment) return

  const imageCount = currentModalEquipment.imagenes.length
  let newIndex

  if (direction === "prev") {
    newIndex = currentModalImageIndex === 0 ? imageCount - 1 : currentModalImageIndex - 1
  } else {
    newIndex = currentModalImageIndex === imageCount - 1 ? 0 : currentModalImageIndex + 1
  }

  setModalImage(newIndex)
}

/**
 * Establece la imagen activa en el modal
 */
function setModalImage(index) {
  if (!currentModalEquipment) return

  currentModalImageIndex = index

  const modalImage = document.getElementById("modalImage")

  // Efecto de transición más lenta
  modalImage.style.opacity = 0
  modalImage.style.transition = "opacity 0.8s ease"

  setTimeout(() => {
    modalImage.src = currentModalEquipment.imagenes[index]
    modalImage.alt = `${currentModalEquipment.modelo} - Imagen ${index + 1}`
    modalImage.style.opacity = 1
  }, 500) // Transición más lenta

  // Actualizar dots
  const dots = document.querySelectorAll("#modalDots .dot")
  dots.forEach((dot, idx) => {
    if (idx === index) {
      dot.classList.add("active")
    } else {
      dot.classList.remove("active")
    }
  })
}

/**
 * Animación de tarjetas para mejor rendimiento
 */
function animateCards() {
  // Detectar si el usuario prefiere reducir el movimiento
  const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches

  if (prefersReducedMotion) {
    // Si prefiere reducir el movimiento, mostrar todas las tarjetas inmediatamente
    document.querySelectorAll(".equipment-card").forEach((card) => {
      card.style.opacity = "1"
      card.style.transform = "translateY(0)"
    })
    return
  }

  // Detectar si es un dispositivo móvil
  const isMobile = window.innerWidth <= 768 || "ontouchstart" in document.documentElement

  // Usar IntersectionObserver para animar las tarjetas cuando entren en el viewport
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const card = entry.target
          const delay = isMobile ? 200 : 300 // Retrasos más largos para transiciones más lentas
          const index = Number.parseInt(card.dataset.equipmentIndex)

          setTimeout(() => {
            card.style.opacity = "1"
            card.style.transform = "translateY(0)"
            card.style.transition = "opacity 1s ease, transform 1s ease" // Transición más lenta
          }, index * delay)

          // Dejar de observar una vez animada
          observer.unobserve(card)
        }
      })
    },
    { threshold: 0.1 },
  )

  // Observar todas las tarjetas
  document.querySelectorAll(".equipment-card").forEach((card) => {
    observer.observe(card)
  })
}

/**
 * Maneja las teclas de navegación
 */
function handleKeyboardNavigation(e) {
  // Si el modal está abierto
  if (document.getElementById("fullscreenModal").classList.contains("active")) {
    if (e.key === "Escape") {
      closeModal()
    } else if (e.key === "ArrowLeft") {
      navigateModal("prev")
    } else if (e.key === "ArrowRight") {
      navigateModal("next")
    }
  } else {
    // Si no hay modal abierto, navegar entre tarjetas
    if (e.key === "ArrowLeft" || e.key === "ArrowRight") {
      if (selectedCardIndex === null) {
        // Si no hay tarjeta seleccionada, seleccionar la primera
        selectedCardIndex = 0
      } else {
        // Navegar entre tarjetas
        if (e.key === "ArrowLeft") {
          selectedCardIndex = selectedCardIndex === 0 ? equipmentData.length - 1 : selectedCardIndex - 1
        } else {
          selectedCardIndex = selectedCardIndex === equipmentData.length - 1 ? 0 : selectedCardIndex + 1
        }
      }

      // Seleccionar la tarjeta
      const cards = document.querySelectorAll(".equipment-card")
      cards.forEach((card) => card.classList.remove("selected"))
      cards[selectedCardIndex].classList.add("selected")

      // Centrar la tarjeta seleccionada en la vista
      cards[selectedCardIndex].scrollIntoView({
        behavior: "smooth",
        block: "center",
      })
    }
  }
}

/**
 * Maneja cambios de orientación del dispositivo
 */
function handleOrientationChange() {
  // Ajustar el modal si está abierto cuando cambia la orientación
  if (document.getElementById("fullscreenModal").classList.contains("active")) {
    const modalContent = document.querySelector(".modal-content")
    const modalImage = document.getElementById("modalImage")

    // Ajustar tamaño de imagen según orientación
    if (window.innerWidth > window.innerHeight) {
      // Landscape
      modalImage.style.maxHeight = "60vh"
      modalContent.style.maxWidth = "90%"
    } else {
      // Portrait
      modalImage.style.maxHeight = "50vh"
      modalContent.style.maxWidth = "95%"
    }
  }
}

/**
 * Cambia entre tema claro y oscuro
 */
function toggleTheme() {
  const html = document.documentElement
  const themeToggle = document.getElementById("themeToggle")
  const icon = themeToggle.querySelector("i")
  const themeColorMeta = document.querySelector('meta[name="theme-color"]')

  if (html.classList.contains("light")) {
    html.classList.replace("light", "dark")
    icon.classList.replace("fa-moon", "fa-sun")
    localStorage.setItem("theme", "dark")
    themeColorMeta.setAttribute("content", "#0f172a") // Color oscuro para la barra de navegación
  } else {
    html.classList.replace("dark", "light")
    icon.classList.replace("fa-sun", "fa-moon")
    localStorage.setItem("theme", "light")
    themeColorMeta.setAttribute("content", "#1e3a8a") // Color claro para la barra de navegación
  }
}

// Inicialización cuando el DOM está listo
document.addEventListener("DOMContentLoaded", () => {
  // Cargar tema guardado
  const savedTheme = localStorage.getItem("theme") || "light"
  document.documentElement.classList.add(savedTheme)

  if (savedTheme === "dark") {
    const icon = document.querySelector("#themeToggle i")
    icon.classList.replace("fa-moon", "fa-sun")

    // Actualizar el color del tema para la barra de navegación móvil
    document.querySelector('meta[name="theme-color"]').setAttribute("content", "#0f172a")
  }

  // Renderizar lista de equipos
  renderEquipmentList()

  // Event listeners
  document.getElementById("themeToggle").addEventListener("click", toggleTheme)

  // Event listeners para el modal
  document.getElementById("fullscreenModal").addEventListener("click", (e) => {
    // Solo cerrar si se hace clic fuera del contenido
    if (e.target === document.getElementById("fullscreenModal")) {
      closeModal()
    }
  })

  document.getElementById("prevImageBtn").addEventListener("click", (e) => {
    e.stopPropagation()
    navigateModal("prev")
  })

  document.getElementById("nextImageBtn").addEventListener("click", (e) => {
    e.stopPropagation()
    navigateModal("next")
  })

  // Añadir listener al botón de cerrar
  document.getElementById("closeModalBtn").addEventListener("click", (e) => {
    e.stopPropagation()
    closeModal()
  })

  // Navegación con teclado
  document.addEventListener("keydown", handleKeyboardNavigation)

  // Listener para cambios de orientación
  window.addEventListener("resize", handleOrientationChange)

  // Detectar si es un dispositivo táctil para optimizar la experiencia
  if ("ontouchstart" in document.documentElement) {
    document.body.classList.add("touch-device")

    // Hacer los botones de navegación siempre visibles en dispositivos táctiles
    const style = document.createElement("style")
    style.textContent = `
      .carousel-btn {
        opacity: 0.8 !important;
      }
      .equipment-card:active {
        transform: scale(0.98);
      }
    `
    document.head.appendChild(style)
  }
})

