// Datos de equipos con múltiples imágenes
const equipmentData = [
  {
    marca: "SENTO",
    modelo: "NODO FLUJO IFM V2 A - A0427",
    dimensiones: "270mm x 220mm x 53mm",
    operacion: "Rango de medición 0,1-25 l/min (20 a 60 °C)",
    Precisión: "±0.02 a ±0.05 pH ",
    alimentacion: "110v / 220v AC",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Medición precisa del caudal, del consumo y de la temperatura de los fluidos",
    caracteristicas:
      "Caudalímetro magneto-inductivo, sin batería, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 5 minutos",
    rangoOperacional: "Hasta 90 metros en línea de vista",
    imagenes: ["imag/ifm1.webp", "imag/ifm2.webp"],
  },
  {
    marca: "SENTO",
    modelo: "NODO RS232 V2 A - A0650",
    dimensiones: "136mm x 99mm x 85mm",
    operacion: "Comunicacion serial protocolo RS232",
    alimentacion: "110v / 220v AC",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Conexión con sensores RS232 (básculas)",
    caracteristicas: "Sin batería, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 5 minutos",
    rangoOperacional: "Hasta 80 metros en línea de vista",
    imagenes: ["imag/rs1.webp", "imag/rs2.webp"],
  },
  {
    marca: "SENTO",
    modelo: "NODO TEMPERATURA DE AGUA WT V2 B - A0310",
    dimensiones: "136mm x 99mm x 85mm",
    operacion: "-55°C hasta 125°C",
    Precisión: "±0,5 °C Precisión de -10 °C a +85 °C",
    alimentacion: "Batería Alcalina AA",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Sensor de temperatura a prueba de agua",
    caracteristicas: "Batería de 6 meses, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 10 minutos",
    rangoOperacional: "Hasta 80 metros en línea de vista",
    imagenes: ["imag/wt.webp", "imag/wt1.webp", "imag/wt2.webp"],
  },
  {
    marca: "SENTO",
    modelo: "NODO TEMPERATURA Y HUMEDAD TH V2 B - A0269",
    dimensiones: "136mm x 99mm x 85mm",
    operacion: "0°C a 125°C",
    Precisión: "±3 % HR / ±0,3 ℃",
    alimentacion: "Batería Alcalina AA",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Medición de temperatura y humedad en exteriores",
    caracteristicas: "Batería de 6 meses, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 10 minutos",
    rangoOperacional: "Hasta 80 metros en línea de vista",
    imagenes: ["imag/th.webp", "imag/th1.webp", "imag/th2.webp"],
  },
  {
    marca: "SENTO",
    modelo: "SENSOR FLUJO AGUA 1 PULGADAS V2 A - A0576",
    dimensiones: "136mm x 99mm x 85mm",
    operacion: "Contador de Pulsos",
    alimentacion: "110v / 220v AC",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Medición de flujo y consumo de agua",
    caracteristicas: "Sin batería, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 10 minutos",
    rangoOperacional: "Hasta 80 metros en línea de vista",
    imagenes: ["imag/wf1.webp", "imag/wf2.webp", "imag/wf3.webp"],
  },
  {
    marca: "SENTO",
    modelo: "CONCENTRADOR WIFI GW V2 A - A0454",
    dimensiones: "270mm x 220mm x 53mm",
    operacion: "Recepcion de datos Lora",
    alimentacion: "110v / 220v AC",
    comunicacion: "WIFI 2400 MHz, Bluetooth",
    aplicacion: "Concentrador principal para recepción de datos",
    caracteristicas: "Batería de litio ion (6 horas), diseñado para ambientes contaminados (Clase A).",
    tiempoTransmision: "Continuo",
    rangoOperacional: "Hasta 90 metros en línea de vista",
    imagenes: ["imag/gw1.webp", "imag/gw2.webp"],
  },
  {
    marca: "SENTO",
    modelo: "NODO FORMALDEHIDO V1 A",
    dimensiones: "136mm x 99mm x 85mm",
    operacion: "Rango de detección: 0~5 ppm",
    Precisión: "±0,01 ppm",
    alimentacion: "110v / 220v AC",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Utiliza un módulo sensor de HCHO en el aire",
    caracteristicas: "Sin batería, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 5 minutos",
    rangoOperacional: "Hasta 80 metros en línea de vista",
    imagenes: ["imag/for1.webp", "imag/for2.webp"],
  },
  {
    marca: "SENTO",
    modelo: "NODO DE PULSOS V1 A - A0787",
    dimensiones: "136mm x 99mm x 85mm",
    operacion: "Contador de pulsos ",
    alimentacion: "110v / 220v AC",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Conexión 3 pines",
    caracteristicas: "Sin batería, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 5 minutos",
    rangoOperacional: "Hasta 80 metros en línea de vista",
    imagenes: ["imag/pul1.webp", "imag/pul2.webp"],
  },
  {
    marca: "SENTO",
    modelo: "NODO MODBUS RS485 V1 A - A0664",
    dimensiones: "136mm x 99mm x 85mm",
    operacion: "Protocolo de comunicación MODBUS",
    alimentacion: "110v / 220v AC",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Comunicación RS485 bidireccional Half duplex",
    caracteristicas: "Sin batería, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 5 minutos",
    rangoOperacional: "Hasta 80 metros en línea de vista",
    imagenes: ["imag/rs485.webp", "imag/rs4852.webp"],
  },
  {
    marca: "SENTO",
    modelo: " Nodo Modbus TCP A - A0651",
    dimensiones: "136mm x 99mm x 85mm",
    operacion: "Protocolo de comunicación Modbus/TCP",
    alimentacion: "110v / 220v AC",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Protocolo Modbus utilizado para comunicaciones a través de redes TCP/IP",
    caracteristicas: "Sin batería, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 5 minutos",
    rangoOperacional: "Hasta 80 metros en línea de vista",
    imagenes: ["imag/tcp1.webp", "imag/tcp2.webp"],
  },
  {
    marca: "SENTO",
    modelo: "CO2 TEMPERATURE HUMIDITY NODE CO&TH V2 A - 0451  ",
    dimensiones: "136mm x 99mm x 85mm",
    operacion: "Rango de medición de 0-2000 ppm",
    Precisión: "±50 ppm ±3% de la lectura ",
    alimentacion: "110v / 220v AC",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Medición de dióxido de carbono en el ambiente",
    caracteristicas: "Sin batería, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 5 minutos",
    rangoOperacional: "Hasta 80 metros en línea de vista",
    imagenes: ["imag/co2.webp", "imag/co21.webp"],
  },
  {
    marca: "SENTO",
    modelo: "Nodo Temperatura Industrial B-A0652",
    dimensiones: "136mm x 99mm x 85mm",
    operacion: "Medición de temperatura de -100 a 200 °C",
    Precisión: "±0.15°C ",
    alimentacion: "Batería Alcalina AA",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Medicion de temperatura en entornos industriales",
    caracteristicas: "Batería de 6 meses, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 10 minutos",
    rangoOperacional: "Hasta 80 metros en línea de vista",
    imagenes: ["imag/ind1.webp", "imag/ind2.webp", "imag/ind3.webp"],
  },
  {
    marca: "SENTO",
    modelo: "KIT MODEM 4G V2.0 - A0560",
    dimensiones: "270mm x 220mm x 53mm",
    operacion: "Redes 4G/LTE (Cat 4), 3G, 2G",
    alimentacion: "110v / 220v AC",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Router industrial para conectividad 4G",
    caracteristicas: "Sin batería, diseñado para ambientes hostiles y contaminados (Clase A).",
    tiempoTransmision: "Continuo",
    rangoOperacional: "Cobertura de red celular",
    imagenes: ["imag/rou1.webp", "imag/rou2.webp"],
  },
  {
    marca: "SENTO",
    modelo: "NODO AGUA PH WN V2 A - A0561",
    dimensiones: "270mm x 220mm x 53mm",
    operacion: "0-14PH",
    Precisión: "±0.02 a ±0.05 pH",
    alimentacion: "110v / 220v AC",
    comunicacion: "WIFI 2400 MHz",
    aplicacion: "Medición de PH en agua 0 ℃ – + 80 ℃, en línea y en tiempo real",
    caracteristicas: "Sin batería, transmisión inalámbrica, para ambientes contaminados (Clase A).",
    tiempoTransmision: "Cada 15 minutos",
    rangoOperacional: "Hasta 90 metros en línea de vista",
    imagenes: ["imag/ph1.webp", "imag/ph2.webp", "imag/ph3.webp"],
  },
]

// Variables globales para el estado del carrusel y modal
let currentModalEquipment = null
let currentModalImageIndex = 0
let autoplayIntervals = []
let selectedCardIndex = null
const activeSlides = {}

// Función para inicializar la página cuando el DOM está listo
document.addEventListener("DOMContentLoaded", () => {
  // Initialize the page
  initPage()

  // Remove page transition after content is loaded
  setTimeout(() => {
    document.querySelector(".page-transition").classList.add("loaded")
  }, 800)
})

// Función principal de inicialización
function initPage() {
  // Cargar tema guardado
  loadSavedTheme()

  // Renderizar lista de equipos
  renderEquipmentList()

  // Configurar event listeners
  setupEventListeners()

  // Establecer el año actual en el footer
  document.getElementById("currentYear").textContent = new Date().getFullYear()
}

// Función para cargar el tema guardado
function loadSavedTheme() {
  const savedTheme = localStorage.getItem("theme") || "light"
  document.documentElement.classList.add(savedTheme)

  if (savedTheme === "dark") {
    const icon = document.querySelector("#themeToggle i")
    icon.classList.replace("fa-moon", "fa-sun")
    document.querySelector('meta[name="theme-color"]').setAttribute("content", "#0f172a")
  }
}

// Función para cambiar entre tema claro y oscuro
function toggleTheme() {
  const html = document.documentElement
  const icon = document.querySelector("#themeToggle i")
  const themeColorMeta = document.querySelector('meta[name="theme-color"]')

  if (html.classList.contains("light")) {
    html.classList.replace("light", "dark")
    icon.classList.replace("fa-moon", "fa-sun")
    localStorage.setItem("theme", "dark")
    themeColorMeta.setAttribute("content", "#0f172a")
  } else {
    html.classList.replace("dark", "light")
    icon.classList.replace("fa-sun", "fa-moon")
    localStorage.setItem("theme", "light")
    themeColorMeta.setAttribute("content", "#1e3a8a")
  }
}

// Configurar todos los event listeners
function setupEventListeners() {
  // Event listener para el botón de tema
  document.getElementById("themeToggle").addEventListener("click", toggleTheme)

  // Event listeners para el modal
  const modal = document.getElementById("fullscreenModal")
  modal.addEventListener("click", (e) => {
    if (e.target === modal) closeModal()
  })

  document.getElementById("prevImageBtn").addEventListener("click", (e) => {
    e.stopPropagation()
    navigateModal("prev")
  })

  document.getElementById("nextImageBtn").addEventListener("click", (e) => {
    e.stopPropagation()
    navigateModal("next")
  })

  document.getElementById("closeModalBtn").addEventListener("click", (e) => {
    e.stopPropagation()
    closeModal()
  })

  // Create overlay for selected card if it doesn't exist
  if (!document.querySelector(".overlay")) {
    const overlay = document.createElement("div")
    overlay.className = "overlay"
    document.body.appendChild(overlay)
  }

  // Navegación con teclado
  document.addEventListener("keydown", (e) => {
    if (document.getElementById("fullscreenModal").classList.contains("active")) {
      if (e.key === "Escape") {
        closeModal()
      } else if (e.key === "ArrowLeft") {
        navigateModal("prev")
      } else if (e.key === "ArrowRight") {
        navigateModal("next")
      }
    } else if (selectedCardIndex !== null && e.key === "Escape") {
      deselectCard()
    }
  })
}

// Update the renderEquipmentList function to apply staggered animations
function renderEquipmentList() {
  // Clear any existing autoplay intervals
  clearAllAutoplayIntervals()

  // Initialize activeSlides
  equipmentData.forEach((_, index) => {
    activeSlides[index] = 0
  })

  const equipmentListElement = document.getElementById("equipmentList")
  equipmentListElement.innerHTML = ""

  // Create and add each card with staggered animation
  equipmentData.forEach((equipment, index) => {
    const card = createEquipmentCard(equipment, index)
    equipmentListElement.appendChild(card)
  })

  // Configure carousels and autoplay
  setupCarousels()
  setupAutoplay()
  setupCardSelection()
}

// Update the createEquipmentCard function to remove animation delay (now handled by CSS)
function createEquipmentCard(equipment, index) {
  // Create card element
  const card = document.createElement("div")
  card.className = "equipment-card"
  card.dataset.index = index
  // Remove animation delay as it's now handled by CSS

  // Crear slides para el carrusel
  const carouselSlides = equipment.imagenes
    .map(
      (imagen, imgIdx) => `
  <div class="carousel-slide ${imgIdx === 0 ? "active" : ""}">
    <img src="${imagen}" 
         alt="${equipment.modelo} - Imagen ${imgIdx + 1}" 
         loading="lazy"
         onerror="this.onerror=null; this.src='placeholder.svg?height=250&width=400'; this.classList.add('fallback-image')" />
  </div>
`,
    )
    .join("")

  // Crear indicadores (dots) para el carrusel
  const carouselDots = equipment.imagenes
    .map(
      (_, imgIdx) => `
  <div class="dot ${imgIdx === 0 ? "active" : ""}" data-index="${imgIdx}" role="button" aria-label="Ver imagen ${
    imgIdx + 1
  }"></div>
`,
    )
    .join("")

  // Estructura HTML de la tarjeta
  card.innerHTML = `
  <h2 class="card-title">
    ${equipment.modelo}
    <span class="badge">${equipment.marca}</span>
  </h2>
  <div class="content">
    <div class="carousel-container" data-equipment-index="${index}">
      ${carouselSlides}
      <button class="carousel-btn prev-btn" data-action="prev" aria-label="Imagen anterior">
        <i class="fas fa-chevron-left" aria-hidden="true"></i>
      </button>
      <button class="carousel-btn next-btn" data-action="next" aria-label="Imagen siguiente">
        <i class="fas fa-chevron-right" aria-hidden="true"></i>
      </button>
      <div class="carousel-dots" role="tablist">
        ${carouselDots}
      </div>
    </div>
    <dl class="specs">
      <dt><i class="fas fa-ruler-combined" aria-hidden="true"></i> Dimensiones:</dt>
      <dd>${equipment.dimensiones}</dd>
      <dt><i class="fas fa-temperature-high" aria-hidden="true"></i> Operación:</dt>
      <dd>${equipment.operacion}</dd>
      <dt><i class="fas fa-crosshairs" aria-hidden="true"></i> Precisión:</dt>
      <dd>${equipment.Precisión || "No especificada"}</dd>
      <dt><i class="fas fa-plug" aria-hidden="true"></i> Alimentación:</dt>
      <dd>${equipment.alimentacion}</dd>
      <dt><i class="fas fa-wifi" aria-hidden="true"></i> Comunicación:</dt>
      <dd>${equipment.comunicacion}</dd>
      <dt><i class="fas fa-clock" aria-hidden="true"></i> Tiempo de Transmisión:</dt>
      <dd>${equipment.tiempoTransmision}</dd>
      <dt><i class="fas fa-broadcast-tower" aria-hidden="true"></i> Rango Operacional:</dt>
      <dd>${equipment.rangoOperacional}</dd>
    </dl>
    <h3 class="section-title"><i class="fas fa-cogs" aria-hidden="true"></i> Aplicación</h3>
    <p class="section-content">${equipment.aplicacion}</p>
    <h3 class="section-title"><i class="fas fa-list-ul" aria-hidden="true"></i> Características</h3>
    <p class="section-content">${equipment.caracteristicas}</p>
  </div>
  <button class="close-card-btn" aria-label="Cerrar tarjeta">
    <i class="fas fa-times"></i>
  </button>
`

  return card
}

// Configurar la selección de tarjetas
function setupCardSelection() {
  const cards = document.querySelectorAll(".equipment-card")
  const overlay = document.querySelector(".overlay")

  // Make sure overlay exists before adding event listener
  if (overlay) {
    overlay.addEventListener("click", (e) => {
      e.stopPropagation()
      deselectCard()
    })
  }

  cards.forEach((card) => {
    card.addEventListener("click", (e) => {
      // If the click was on a carousel container, button, dot, or close button, don't select the card
      if (
        e.target.closest(".carousel-container") ||
        e.target.closest(".carousel-btn") ||
        e.target.closest(".dot") ||
        e.target.closest(".close-card-btn")
      ) {
        return
      }

      // Verify if the card is already selected
      const isAlreadySelected = card.classList.contains("selected")

      // If a card is already selected, deselect it first
      if (selectedCardIndex !== null) {
        deselectCard()

        // If we're clicking the same card that was already selected, just deselect it and return
        if (isAlreadySelected) {
          return
        }
      }

      // Select the new card
      selectCard(card)
    })

    // Add event listener for the close button
    const closeBtn = card.querySelector(".close-card-btn")
    if (closeBtn) {
      closeBtn.addEventListener("click", (e) => {
        e.stopPropagation()
        deselectCard()
      })
    }
  })
}

// Add a new function to handle card selection
function selectCard(card) {
  // Desactivar todas las transiciones normales temporalmente
  card.style.transition = "none"

  // Añadir clase 'selected' a la tarjeta inmediatamente
  card.classList.add("selected")

  // Activar el overlay
  const overlay = document.querySelector(".overlay")
  overlay.style.transition = "opacity 0.3s"
  overlay.classList.add("active")

  // Prevenir scroll en el body
  document.body.style.overflow = "hidden"

  // Bloquear el puntero en la tarjeta seleccionada
  card.style.cursor = "default"

  // Asegurarse de que el título esté visible
  const cardTitle = card.querySelector(".card-title")
  if (cardTitle) {
    cardTitle.style.position = "sticky"
    cardTitle.style.top = "0"
    cardTitle.style.zIndex = "10"
  }

  // Save the selected card index
  selectedCardIndex = Number.parseInt(card.dataset.index)

  // Restaurar la transición después de un breve retraso
  setTimeout(() => {
    card.style.transition = ""
  }, 50)
}

// Función para deseleccionar la tarjeta
function deselectCard() {
  if (selectedCardIndex === null) return

  const card = document.querySelector(`.equipment-card[data-index="${selectedCardIndex}"]`)
  const overlay = document.querySelector(".overlay")

  if (card) {
    // Desactivar transiciones temporalmente
    card.style.transition = "none"
    card.classList.remove("selected")
    card.style.cursor = "pointer"

    // Restaurar el estilo del título
    const cardTitle = card.querySelector(".card-title")
    if (cardTitle) {
      cardTitle.style.position = ""
      cardTitle.style.top = ""
      cardTitle.style.zIndex = ""
    }

    // Restaurar la transición después de un breve retraso
    setTimeout(() => {
      card.style.transition = ""
    }, 50)
  }

  if (overlay) {
    overlay.classList.remove("active")
  }

  // Re-enable scroll
  document.body.style.overflow = ""
  selectedCardIndex = null

  // Add a small delay to prevent immediate reselection
  setTimeout(() => {
    // This helps prevent issues with rapid clicking
  }, 100)
}

// Configurar los carruseles
function setupCarousels() {
  document.querySelectorAll(".carousel-container").forEach((container) => {
    const equipmentIndex = Number.parseInt(container.dataset.equipmentIndex)
    const equipment = equipmentData[equipmentIndex]

    // Listeners for navigation buttons
    container.querySelector(".prev-btn").addEventListener("click", (e) => {
      e.stopPropagation()
      navigateCarousel(container, "prev")
    })

    container.querySelector(".next-btn").addEventListener("click", (e) => {
      e.stopPropagation()
      navigateCarousel(container, "next")
    })

    // Listeners for dots
    container.querySelectorAll(".dot").forEach((dot) => {
      dot.addEventListener("click", (e) => {
        e.stopPropagation()
        setActiveSlide(container, Number.parseInt(dot.dataset.index))
      })
    })

    // Listener for the carousel container to open modal
    container.addEventListener("click", (e) => {
      // If the click was on a button or dot, don't open the modal
      if (e.target.closest(".carousel-btn") || e.target.closest(".dot")) {
        return
      }

      // Find the index of the active image
      const activeSlideIndex = Array.from(container.querySelectorAll(".carousel-slide")).findIndex((slide) =>
        slide.classList.contains("active"),
      )

      // Open the modal with the active image
      openModal(equipment, activeSlideIndex)

      // Prevent event propagation to avoid card selection
      e.stopPropagation()
    })
  })
}

// Modify the setupAutoplay function to prevent autoplay when hovering
function setupAutoplay() {
  const carouselContainers = document.querySelectorAll(".carousel-container")

  // Detectar si es un dispositivo móvil
  const isMobile = window.innerWidth <= 768 || "ontouchstart" in document.documentElement

  carouselContainers.forEach((container, index) => {
    // Intervalo más largo para móviles para ahorrar batería
    const intervalTime = isMobile ? 10000 + index * 500 : 8000 + index * 500

    // Crear un intervalo para cada carrusel
    const interval = setInterval(() => {
      if (selectedCardIndex === null) {
        // Solo autoplay cuando no hay tarjeta seleccionada
        navigateCarousel(container, "next")
      }
    }, intervalTime)

    // Guardar referencia al intervalo
    autoplayIntervals.push(interval)

    // Pausar autoplay al interactuar
    const pauseAutoplay = () => {
      clearInterval(interval)

      // Remove the interval from the array
      const intervalIndex = autoplayIntervals.indexOf(interval)
      if (intervalIndex !== -1) {
        autoplayIntervals.splice(intervalIndex, 1)
      }
    }

    // NO reanudar autoplay al dejar de interactuar - this is the key change
    // We're removing the resumeAutoplay functionality when mouse leaves

    // Eventos para escritorio - only pause, don't resume
    container.addEventListener("mouseenter", pauseAutoplay)
    // Removed the mouseleave event that would resume autoplay

    // Eventos para móviles - only pause on touch, don't resume
    container.addEventListener("touchstart", pauseAutoplay)
    // Removed the touchend event that would resume autoplay
  })
}

// Limpiar todos los intervalos de autoplay
function clearAllAutoplayIntervals() {
  autoplayIntervals.forEach((interval) => clearInterval(interval))
  autoplayIntervals = []
}

// Navegar entre las imágenes del carrusel
function navigateCarousel(container, direction) {
  const slides = container.querySelectorAll(".carousel-slide")
  const activeSlideIndex = Array.from(slides).findIndex((slide) => slide.classList.contains("active"))

  // Calculate new index with proper wrapping
  let newIndex
  if (direction === "prev") {
    newIndex = activeSlideIndex <= 0 ? slides.length - 1 : activeSlideIndex - 1
  } else {
    newIndex = activeSlideIndex >= slides.length - 1 ? 0 : activeSlideIndex + 1
  }

  // Apply transition
  setActiveSlide(container, newIndex)
}

// Establecer la imagen activa en el carrusel
function setActiveSlide(container, index) {
  const slides = container.querySelectorAll(".carousel-slide")
  const dots = container.querySelectorAll(".dot")

  // Desactivar todos
  slides.forEach((slide) => {
    slide.classList.remove("active")
    slide.style.zIndex = 0
  })

  dots.forEach((dot) => dot.classList.remove("active"))

  // Activar el nuevo
  slides[index].classList.add("active")
  slides[index].style.zIndex = 1
  dots[index].classList.add("active")

  // Efecto de transición suave
  slides.forEach((slide) => {
    if (!slide.classList.contains("active")) {
      slide.style.opacity = 0
      slide.style.transition = "opacity 1.2s ease-in-out"
    } else {
      slide.style.opacity = 1
      slide.style.transition = "opacity 1.2s ease-in-out"
    }
  })

  // Actualizar el estado global
  const equipmentIndex = Number.parseInt(container.dataset.equipmentIndex)
  activeSlides[equipmentIndex] = index
}

// Abrir el modal con la imagen seleccionada
function openModal(equipment, imageIndex = 0) {
  currentModalEquipment = equipment
  currentModalImageIndex = imageIndex

  const modal = document.getElementById("fullscreenModal")
  const modalImage = document.getElementById("modalImage")
  const modalTitle = document.getElementById("modalTitle")
  const modalDescription = document.getElementById("modalDescription")
  const modalDots = document.getElementById("modalDots")

  // Preload image to prevent flickering
  const img = new Image()
  img.onload = () => {
    modalImage.src = equipment.imagenes[imageIndex]
    modalImage.alt = `${equipment.modelo} - Imagen ${imageIndex + 1}`

    // Show modal after image is loaded
    modal.classList.add("active")
    document.body.style.overflow = "hidden"

    // Focus close button for accessibility
    setTimeout(() => {
      document.getElementById("closeModalBtn").focus()
    }, 100)
  }

  img.onerror = () => {
    // Fallback if image fails to load
    modalImage.src = "placeholder.svg?height=400&width=600"
    modalImage.alt = `${equipment.modelo} - Imagen no disponible`
    modal.classList.add("active")
    document.body.style.overflow = "hidden"
  }

  img.src = equipment.imagenes[imageIndex]

  // Set text content
  modalTitle.textContent = equipment.modelo
  modalDescription.textContent = equipment.aplicacion

  // Create dots
  modalDots.innerHTML = equipment.imagenes
    .map(
      (_, idx) => `
    <div class="dot ${idx === imageIndex ? "active" : ""}" 
         data-index="${idx}" 
         role="button" 
         aria-label="Ver imagen ${idx + 1}"></div>
  `,
    )
    .join("")

  // Add event listeners to dots
  modalDots.querySelectorAll(".dot").forEach((dot) => {
    dot.addEventListener("click", (e) => {
      e.stopPropagation()
      setModalImage(Number.parseInt(dot.dataset.index))
    })
  })
}

// Cerrar el modal
function closeModal() {
  const modal = document.getElementById("fullscreenModal")

  // Animación de cierre
  modal.classList.remove("active")
  document.body.style.overflow = "" // Restaurar scroll

  currentModalEquipment = null
  currentModalImageIndex = 0
}

// Navegar entre imágenes en el modal
function navigateModal(direction) {
  if (!currentModalEquipment) return

  const imageCount = currentModalEquipment.imagenes.length
  const newIndex =
    direction === "prev"
      ? currentModalImageIndex === 0
        ? imageCount - 1
        : currentModalImageIndex - 1
      : currentModalImageIndex === imageCount - 1
        ? 0
        : currentModalImageIndex + 1
  setModalImage(newIndex)
}

// Establecer la imagen activa en el modal
function setModalImage(index) {
  if (!currentModalEquipment) return

  currentModalImageIndex = index
  const modalImage = document.getElementById("modalImage")

  // Smooth transition
  modalImage.style.opacity = 0

  // Preload image
  const img = new Image()
  img.onload = () => {
    setTimeout(() => {
      modalImage.src = currentModalEquipment.imagenes[index]
      modalImage.alt = `${currentModalEquipment.modelo} - Imagen ${index + 1}`
      modalImage.style.opacity = 1
    }, 300)
  }

  img.onerror = () => {
    setTimeout(() => {
      modalImage.src = "placeholder.svg?height=400&width=600"
      modalImage.alt = `${currentModalEquipment.modelo} - Imagen no disponible`
      modalImage.style.opacity = 1
    }, 300)
  }

  img.src = currentModalEquipment.imagenes[index]

  // Update  // Update dots
  document.querySelectorAll("#modalDots .dot").forEach((dot, idx) => {
    dot.classList.toggle("active", idx === index)
  })
}

// Añadir event listeners a las tarjetas
document.querySelectorAll(".equipment-card").forEach((card) => {
  card.addEventListener("click", () => selectCard(card))
})

// Añadir event listener al botón de cierre
document.querySelectorAll(".close-card-btn").forEach((btn) => {
  btn.addEventListener("click", (e) => {
    e.stopPropagation()
    deselectCard()
  })
})

// Cerrar la tarjeta al hacer clic en el overlay
document.querySelector(".overlay").addEventListener("click", deselectCard)

// Prevenir que los clics dentro de la tarjeta seleccionada cierren la tarjeta
document.querySelectorAll(".equipment-card").forEach((card) => {
  card.addEventListener("click", (e) => {
    if (card.classList.contains("selected")) {
      e.stopPropagation()
    }
  })
})

